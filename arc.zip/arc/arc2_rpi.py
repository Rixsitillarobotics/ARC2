import requests
from datetime import datetime
ser = None
import serial
import time
import openai
import cv2
import subprocess
import base64
import os
from gtts import gTTS

# === TELEGRAM CONFIG ===
TELEGRAM_BOT_TOKEN = "******************"
TELEGRAM_CHAT_ID = "***********"

# === SETUP SERIAL ===
try:
    ser = serial.Serial("/dev/ttyACM0", 9600, timeout=1)
    time.sleep(2)
    print("✅ Arduino connected.")
except:
    print("⚠️ Arduino not found.")
    ser = None

# === GPS FUNCTION: Read from Arduino Serial ===
def get_latest_gps():
    try:
        if ser and ser.in_waiting:
            while ser.in_waiting:
                line = ser.readline().decode(errors='ignore').strip()
                if line.startswith("🌍 Latitude:"):
                    try:
                        lat_part = line.split("Latitude:")[1].split("|")[0].strip()
                        lon_part = line.split("Longitude:")[1].strip()
                        latitude = float(lat_part)
                        longitude = float(lon_part)
                        return latitude, longitude
                    except:
                        continue
        return None, None
    except:
        return None, None

# === SPEAK FUNCTION ===
def speak(text):
    try:
        tts = gTTS(text=text, lang='en', slow=False)
        tts.save("speech.mp3")
        os.system("mpg123 -q speech.mp3")
    except Exception as e:
        print(f"❌ TTS failed: {e}")

# === CONFIGURATION ===
openai.api_key = "sk-**************************************"
SERIAL_PORT = "/dev/ttyACM0"
BAUD_RATE = 9600
IMAGE_PATH = "view.jpg"

COMMAND_ALIASES = {
    "forward": ["forward", "go forward", "move forward", "ahead"],
    "backward": ["backward", "go back", "move back", "reverse"],
    "left": ["left", "turn left", "go left"],
    "right": ["right", "turn right", "go right"],
    "sideleft": ["sideleft", "strafe left", "slide left"],
    "sideright": ["sideright", "strafe right", "slide right"],
    "stop": ["stop", "halt", "freeze", "do not move"]
}

COMMANDS = {"forward", "backward", "left", "right", "sideleft", "sideright", "stop"}

def normalize_command(text):
    text = text.strip().lower()
    for line in text.splitlines():
        for cmd, aliases in COMMAND_ALIASES.items():
            for alias in aliases:
                if alias in line:
                    return cmd
    return None

def extract_command_from_gpt_response(response):
    lines = response.splitlines()
    for line in lines:
        if line.strip().lower().startswith("command:"):
            command_line = line[len("command:"):].strip().lower()
            return normalize_command(command_line)
    return normalize_command(lines[0].strip().lower()) if lines else None

# === CAPTURE IMAGE ===
def capture_image():
    cap = cv2.VideoCapture(0)
    for _ in range(3):
        if cap.isOpened():
            ret, frame = cap.read()
            if ret:
                cv2.imwrite(IMAGE_PATH, frame)
                cap.release()
                return IMAGE_PATH
        time.sleep(1)
    cap.release()
    print("❌ Failed to capture image.")
    return None

# === ASK GPT ===
def ask_gpt(image_path, prompt, strict=True):
    with open(image_path, "rb") as image_file:
        base64_image = base64.b64encode(image_file.read()).decode("utf-8")

    if strict:
        system_msg = (
            "You are the intelligent brain of an autonomous robot that can move, turn, side step, stop, and explore. "
            "You fully control the robot. Only respond with ONE command: forward, backward, left, right, sideleft, sideright, or stop."
        )
    else:
        system_msg = (
            "You are the brain of an exploring robot. Describe what you see and provide a clear command to move toward the user's goal. "
            "Then say ONE command: forward, backward, left, right, sideleft, sideright, or stop."
        )
for _ in range(2):
        try:
            response = openai.chat.completions.create(
                model="gpt-5",
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {
                            "url": f"data:image/jpeg;base64,{base64_image}"}}
                    ]}
                ],
                max_tokens=100 if not strict else 20
            )
            reply = response.choices[0].message.content.strip()
            return reply
        except Exception as e:
            print("❌ GPT Error:", e)
        time.sleep(1)
    return None

# === SEND COMMAND TO ARDUINO ===
def send_command(cmd):
    if ser:
        try:
            clean_cmd = cmd.strip().lower()
            print(f"🧪 Sending to Arduino: {repr(clean_cmd)}")
            ser.write((clean_cmd + "\n").encode())
            time.sleep(0.55)
            ser.write(b"stop\n")
        except:
            print("❌ Serial write failed.")

# === SEND IMAGE AND LOCATION TO TELEGRAM ===
def send_to_telegram(image_path, description, latitude, longitude):
    try:
        with open(image_path, "rb") as img:
            files = {'photo': img}
            data = {'chat_id': TELEGRAM_CHAT_ID, 'caption': description}
            photo_url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendPhoto"
            requests.post(photo_url, files=files, data=data)

        if latitude and longitude and (latitude != 0.0 and longitude != 0.0):
            map_link = f"https://maps.google.com/?q={latitude},{longitude}"
            text_data = {
                'chat_id': TELEGRAM_CHAT_ID,
                'text': f"🌍 Location: {latitude:.6f}, {longitude:.6f}\n📍 Google Maps: {map_link}"
            }
        else:
            text_data = {
                'chat_id': TELEGRAM_CHAT_ID,
                'text': "❌ No satellites / GPS fix. Location unavailable."
            }
        msg_url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        requests.post(msg_url, data=text_data)

    except Exception as e:
        import traceback
        traceback.print_exc()

# === TEXT MODE ===
def text_mode():
    last_command = None
    user_input = input("💬 What do you want the robot to do? ").strip()
    if not user_input:
        return
    img = capture_image()
    if not img:
        return
    print("🤖 Asking GPT...")
    while True:
        description = ask_gpt(img, f"Describe what you see. Goal: {user_input}", strict=False)
        if not description:
            break
        command_clean = extract_command_from_gpt_response(description)
        description_with_command = f"{description} Command: {command_clean}" if command_clean else description
        print("📝 GPT Description:", description_with_command)
        speak(description_with_command)
        gps_lat, gps_lon = None, None
        for _ in range(3):
            gps_lat, gps_lon = get_latest_gps()
            if gps_lat and gps_lon:
                break
            time.sleep(1)
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        description_with_time = f"{description_with_command}\n🕒 {timestamp}"
        send_to_telegram(img, description_with_time, gps_lat, gps_lon)
        if command_clean and command_clean in COMMANDS:
            print(f"Command: {command_clean}")
            send_command(command_clean)
            last_command = command_clean
            time.sleep(3)
            img = capture_image()
            if not img:
                break
        else:
            print(f"❌ GPT did not return a valid command. Received: {description.strip()}")
            speak("Sorry, I couldn't understand the next move.")
            continue

# === AUTO EXPLORE ===
def explore_loop():
    print(f"🔁 Starting open-ended explore loop...")
    cycle = 0
    while True:
        cycle += 1
        print(f"\n🔄 Cycle {cycle}")
        img = capture_image()
        if not img:
            continue
        describe_prompt = "Describe what you see in this image. Mention objects, people, terrain, or clues."
        speak("Describing the scene.")
        description = ask_gpt(img, describe_prompt, strict=False)
        if description:
            command_clean = extract_command_from_gpt_response(description)
            description_with_command = f"{description} Command: {command_clean}" if command_clean else description
            print("📝 GPT Description:", description_with_command)
            speak(description_with_command)
            gps_lat, gps_lon = None, None
            for _ in range(3):
                gps_lat, gps_lon = get_latest_gps()
                if gps_lat and gps_lon:
                    break
                time.sleep(1)
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            description_with_time = f"{description_with_command}\n🕒 {timestamp}\n🔁 Cycle: {cycle}"
            send_to_telegram(img, description_with_time, gps_lat, gps_lon)
            if command_clean:
                print("💬 GPT Command:", command_clean)
                send_command(command_clean)
                if command_clean == "stop":
                    print("🛑 GPT decided to stop — continuing to explore.")
                    continue
                time.sleep(2)
            else:
                print("🤖 No valid command.")
                time.sleep(2)
        else:
            print("🤖 Failed to get a description.")
            continue

# === MAIN LOOP ===
def main_loop():
    while True:
        mode = input("💬 Choose mode — t to type, e to auto-explore, q to quit: ").strip().lower()
        if mode == "q":
            return
        if mode == "e":
            explore_loop()
        elif mode == "t":
            text_mode()
        else:
            print("❌ Invalid option. Try again.")

if name == "__main__":
    main_loop()
                    